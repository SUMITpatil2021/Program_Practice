/**
 * 
 */
/**
 * 
 */
module JAVA_program_practice {
}