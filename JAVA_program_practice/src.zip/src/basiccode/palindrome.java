package basiccode;

public class palindrome {
	
	public static boolean isPalindrome(int num)
	{
		boolean flag=false;
		
		return flag;
	}
	public static void main(String []args)
	{
	boolean palindrome=isPalindrome(1001);
	}
}
